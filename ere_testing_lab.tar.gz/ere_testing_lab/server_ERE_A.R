#Tool Tips

addTooltip(session=session,id="btn",title="Hello! This is a hover pop-up. You'll have to click to see the next one.")

count.data <- data.frame(
  class = c("1st", "2nd", "3rd", "Crew"),
  n = c(325, 285, 706, 885),
  prop = c(14.8, 12.9, 32.1, 40.2)
)

count.data <- count.data %>%
  arrange(desc(class)) %>%
  mutate(lab.ypos = cumsum(prop) - 0.5 * prop)
count.data

mycols <- c("#0073C2FF", "#EFC000FF", "#868686FF", "#CD534CFF")



output$Plot1 <- renderPlot({
  ggplot(count.data, aes(x = 2, y = prop, fill = class)) +
    geom_bar(stat = "identity", color = "white") +
    coord_polar(theta = "y", start = 0) +
    geom_text(aes(y = lab.ypos, label = prop), color = "white") +
    scale_fill_manual(values = mycols) +
    theme_void() +
    xlim(0.5, 2.5)
})

output$Plot2 <- renderPlot({
ggplot(count.data, aes(x = 2, y = prop, fill = class)) +
  geom_bar(stat = "identity", color = "white") +
  coord_polar(theta = "y", start = 0)+
  geom_text(aes(y = lab.ypos, label = paste0("n = ", n, ", \n", prop, "%")), color = "white")+
  scale_fill_manual(values = mycols) +
  theme_void() +
  xlim(.5, 2.5) +
  annotate(geom = 'text', x = 0.5, y = 0, label = paste0(count.data$prop[count.data$class == 'Crew'], "%"))
  
})

output$outputBox1 <- renderGauge({ 
  flexdashboard::gauge(input$value_2+10, min = 0, max = 100, symbol = '%', gaugeSectors(
    success = c(71, 100), warning = c(39, 50), danger = c(0, 39)
  ))
})
output$outputBox2 <- renderGauge({ 
  flexdashboard::gauge(input$value_2, min = 0, max = 100, symbol = '%', gaugeSectors(
    success = c(71, 100), warning = c(39, 50), danger = c(0, 39)
  ))
})
output$outputBox3 <- renderGauge({ 
  flexdashboard::gauge(input$value_2-10, min = 0, max = 100, symbol = '%', gaugeSectors(
    success = c(71, 100), warning = c(39, 50), danger = c(0, 39)
  ))
})

df <- tibble(
  name = c("Animals", "Fruits","Cars"),
  y = c(5, 2, 6),
  drilldown = tolower(name)
)

dfan <- data.frame(
  name = c("Cats", "Dogs", "Cows", "Sheep", "Pigs"),
  value = c(4, 3, 1, 2, 1)
)

dffru <- data.frame(
  name = c("Apple", "Organes","grapes"),
  value = c(4, 2, 3)
)

dfcar <- data.frame(
  name = c("BMW", "Mercedes", "Honda", "Toyota", "Mazda", "Ford"),
  value = c(4, 3, 1, 2, 1,5)
)


dsan <- list_parse2(dfan)

dsfru <- list_parse2(dffru)

dfcar <- list_parse2(dfcar )

output$hcontainer <- renderHighchart({
  
  hc <- highchart() %>%
  hc_title(text = "Basic drilldown") %>%
  hc_xAxis(type = "category") %>%
  hc_legend(enabled = FALSE) %>%
  hc_plotOptions(
    series = list(
      boderWidth = 0,
      dataLabels = list(enabled = TRUE)
    )
  ) %>%
  hc_add_series(
    data = df,
    type = "pie",
    hcaes(name = "name", y = "y"),
    name = "Things",
    colorByPoint = TRUE
  )

  if (input$theme != FALSE) {
      theme <- switch(input$theme,
                      null = hc_theme_null(),
                      darkunica = hc_theme_darkunica(),
                      gridlight = hc_theme_gridlight(),
                      sandsignika = hc_theme_sandsignika(),
                      fivethirtyeight = hc_theme_538(),
                      economist = hc_theme_economist(),
                      chalk = hc_theme_chalk(),
                      handdrwran = hc_theme_handdrawn(),
                      monokai = hc_theme_monokai(),
                      ffx = hc_theme_ffx(),
                      tufte = hc_theme_tufte(),
                      db = hc_theme_db(),
                      flat = hc_theme_flat(),
                      google = hc_theme_google()
              
      )

      hc <- hc %>% hc_add_theme(theme)
   }
  
  hc <- hc %>%
  hc_drilldown(
    allowPointDrilldown = TRUE, 
    series = list(
      list(
        id = "animals",
        data = dsan,
        type = 'column'
      ),
      list(
        id = "fruits",
        data = dsfru,
        type = 'pie',
        startAngle = -90, #pie  | Start of semi circle
        endAngle = 90, #pie  | End of semi circle
        center = c('50%', '90%'), #c('<x-axis>', '<y-axis>') | adjust the location of center of semi circle
        size = '100%', #pie,
        innerSize = 300 # This makes pie chart a donut chart

      ),
        list(
        id = "cars",
        data = dfcar,
        type = 'pie',
        startAngle = -90, #pie  | Start of semi circle
        endAngle = 90, #pie  | End of semi circle
        center = c('50%', '90%'), #c('<x-axis>', '<y-axis>') | adjust the location of center of semi circle
        size = '100%', #pie,
        innerSize = 300 # This makes pie chart a donut chart

      )

    )
  )
  
  hc
  
})