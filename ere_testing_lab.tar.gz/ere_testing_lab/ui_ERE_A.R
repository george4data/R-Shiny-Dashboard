tab_ERE_A_1 <- tabPanel("Home")
tab_ERE_A_2 <- tabPanel(
  "Client Experience Indicators",


  box(
    title = "Box with boxPad containing inputs",
    status = "warning",
    solidHeader = FALSE,
    width = NULL,
    fluidRow(
      column(
        width = 4,
        boxPad(
          color = "gray",
          sliderInput(
            "obs2", 
            "Number of observations:",
            min = 0, max = 1000, value = 500
          ),
          checkboxGroupInput(
            "variable", 
            "Variables to show:",
            c("Cylinders" = "cyl",
              "Transmission" = "am",
              "Gears" = "gear")
          ),
          
          knobInput(
            inputId = "myKnob",
            skin = "tron",
            readOnly = TRUE,
            label = "Display previous:",
            value = 4,
            min = 0,
            max = 5,
            step = 1,
            #post = "$",
            displayPrevious = TRUE,
            fgColor = "#428BCA",
            inputColor = "#428BCA"
          )
        )
      ),
      column(width = 6,
             fluidRow(
               column(
                 width = 6,
                 descriptionBlock(
                   #width=3,
                   number = "18%",
                   number_color = "red",
                   number_icon = "fa fa-caret-down",
                   header = "1200",
                   text = "GOAL COMPLETION",
                   right_border = FALSE,
                   margin_bottom = TRUE
                 )
               ),
               column(
                 width = 6,
                 descriptionBlock(
                   #width=3,
                   number = "17%",
                   number_color = "green",
                   number_icon = "fa fa-caret-up",
                   header = "$35,210.43",
                   text = "TOTAL REVENUE",
                   right_border = FALSE,
                   margin_bottom = TRUE
                 )
               ),
               plotOutput("Plot1")
             )), 
      column(
        width = 2,

        knobInput(
          inputId = "myKnob2",
          skin = NULL,
          readOnly = TRUE,
          label = "Display previous:",
          value = 4,
          min = 0,
          max = 5,
          step = 1,
          #height = "200px",
          #post = "A",
          #lineCap = "round",
          angleOffset = 270,
          angleArc = 180,
          displayPrevious = TRUE,
          fgColor = "#428BCA",
          inputColor = "#428BCA"
        ),
        knobInput(
          inputId = "myKnob3",
          skin = NULL,
          readOnly = TRUE,
          label = "Display previous:",
          value = 4,
          min = 0,
          max = 5,
          step = 1,
          #height = "200px",
          #post = "$",
          #lineCap = "round",
          angleOffset = 270,
          angleArc = 180,
          displayPrevious = TRUE,
          fgColor = "#EFC000FF",
          inputColor = "#428BCA"
        ),
        knobInput(
          inputId = "myKnob3",
          skin = NULL,
          readOnly = TRUE,
          label = "Display previous:",
          value = 4,
          min = 0,
          max = 5,
          step = 1,
          #height = "200px",
          #post = "$",
          #lineCap = "round",
          angleOffset = 270,
          angleArc = 180,
          displayPrevious = TRUE,
          fgColor = "#868686FF",
          inputColor = "#428BCA"
        )
      )
    )
  ),#EOF Box
  
  box(
    title = "Box with boxPad containing inputs",
    status = "info",
    solidHeader = TRUE,
    width = NULL,
    fluidRow(
      column(
        width = 6,
        plotOutput("Plot2")
      ),
      column(
        width = 6,
        boxPad(
          color = "gray",
          sliderInput(
            "obs2", 
            "Number of observations:",
            min = 0, max = 1000, value = 500
          ),
          checkboxGroupInput(
            "variable", 
            "Variables to show:",
            c("Cylinders" = "cyl",
              "Transmission" = "am",
              "Gears" = "gear")
          ),
          
          knobInput(
            inputId = "myKnob1",
            skin = "tron",
            readOnly = TRUE,
            label = "Display previous:",
            value = 4,
            min = 0,
            max = 5,
            step = 1,
            #post = "$",
            displayPrevious = TRUE,
            fgColor = "#428BCA",
            inputColor = "#428BCA"
          )
        )
      )

    )
  ),#EOF Box
  # boxPlus(
  #   width = 12,
  #   title = "boxPlus with sidebar",
  #   closable = TRUE,
  #   status = "warning",
  #   solidHeader = FALSE,
  #   collapsible = TRUE,
  #   enable_sidebar = TRUE,
  #   sidebar_width = 25,
  #   sidebar_start_open = TRUE,
  #   sidebar_content = tagList(
  #     checkboxInput("somevalue", "Some value", FALSE),
  #     verbatimTextOutput("value"),
  #     sliderInput(
  #       "slider_boxsidebar",
  #       "Number of observations:",
  #       min = 0,
  #       max = 1000,
  #       value = 500
  #     )
  #   ),
  #   plotOutput("Plot1")
  # ),#EOF boxPlus
  
  
  box(
    title = "verticalProgress",
    width = NULL,
    verticalProgress(
      value = 10,
      striped = TRUE,
      active = TRUE
    ),
    verticalProgress(
      value = 50,
      active = TRUE,
      status = "warning",
      size = "xs"
    ),
    verticalProgress(
      value = 20,
      status = "danger",
      size = "sm",
      height = "60%"
    )
  ),#EOF Box
  

  
  fluidRow(
    box(title = "Progress Bars Different Sizes",
        p("Normal"),
        prgoressBar(40, color = "primary", striped = TRUE),
        p("Small"),
        prgoressBar(20, color = "green", striped = TRUE, active = TRUE, size = "sm"),
        p("Extra small"),
        prgoressBar(60, color = "orange", striped = TRUE, size = "xs"),
        p("Extra extra small"),
        prgoressBar(60, color = "red", striped = TRUE, size = "xxs")
    ),
    box(title = "Progress bars",
        prgoressBar(40, color = "green"),
        prgoressBar(20, color = "aqua"),
        prgoressBar(60, color = "yellow"),
        prgoressBar(80, color = "red")
    )
  ),
  fluidRow(
    box(title = "Progress Bars Different Sizes",
        class = "text-center",
        prgoressBar(40, color = "primary", striped = TRUE, active = TRUE, vertical = TRUE),
        prgoressBar(100, color = "green", vertical = TRUE, size = "sm"),
        prgoressBar(50, color = "yellow", striped = TRUE, vertical = TRUE, size = "xs"),
        prgoressBar(50, color = "aqua", vertical = TRUE, size = "xxs")
    ),
    box(title = "Vertical Progress bars",
        class = "text-center",
        prgoressBar(40, color = "green", vertical = TRUE),
        prgoressBar(20, color = "aqua", vertical = TRUE),
        prgoressBar(60, color = "yellow", vertical = TRUE),
        prgoressBar(80, color = "red", vertical = TRUE)
    )
  ),
  fluidRow(
    box(title = "Progress Groups",
        p(strong("Goal Completion"), class = "text-center"),
        progressGroup("Add Products to Cart", 160, 0, 200),
        progressGroup("Complete Purchase", 310, 0, 400, color = "red"),
        progressGroup("Visit Premium Page", 480, 0, 800, color = "green"),
        progressGroup("Send Inquiries", 250, 0, 500, color = "yellow")
    )
  ),
  fluidRow(
  
    carousel(
      id = "mycarousel",
      carousel(
        id = "carosel",
        carouselItem("1", textOutput("text1")),
        carouselItem("2", textOutput("text2")),
        carouselItem("this works")
      )
    )
  
  )

 
) #EOF tabPanel
tab_ERE_A_3 <- tabPanel(
  "Operational Efficiency",
  box(
    title = "Box with boxPad containing inputs",
    status = "info",
    solidHeader = TRUE,
    width = NULL,
    fluidRow(
      column(
        width = 9,
        column(width = 4,
               flexdashboard::gaugeOutput("outputBox1")),
        column(width = 4,
               flexdashboard::gaugeOutput("outputBox2")),
        column(width = 4,
               flexdashboard::gaugeOutput("outputBox3"))
      ),
      column(width = 3,
             boxPad(
               color = "gray",
               sliderInput("value_2", "Number of observations:", 1, 90, 70)
             ))
      
    )
  )
  
)
tab_ERE_A_4 <- tabPanel("Strategy Effectiveness",
                        tags$style(HTML("
                          .tooltip > .tooltip-inner {
                           width: 400px;
                           color: white;
                           arrow: #01a9b4;
                           background-color: #01a9b4;
                           }
                         ")),
                        tags$style(HTML("
                          .tooltip.bottom > .tooltip-arrow {
                                        border-bottom-color: #01a9b4;
                                        }
                                        ")),
                        titlePanel("ShinyBS tooltips"),
                        actionButton("btn", "On hover"),
                        #Tool Tip located on sercer_ERE_A.R
                        tipify(actionButton("btn2", "On click"), "Hello again! This is a click-able pop-up", placement="bottom", trigger = "click"),
                        popify(bsButton("pointlessButton", "Button", style = "primary", size = "large"),
                               "A Pointless Button",
                               "This button is <b>pointless</b>. It does not do <em>anything</em>!"),
                        tipify(bsButton("pB2", "Button", style = "inverse", size = "extra-small"),
                               "This button is pointless too!"),
                        knobInput(
                          inputId = "myKnob5",
                          skin = NULL,
                          readOnly = TRUE,
                          label = "Display previous:",
                          value = 4,
                          min = 0,
                          max = 5,
                          step = 1,
                          #height = "200px",
                          #post = "$",
                          #lineCap = "round",
                          angleOffset = 270,
                          angleArc = 180,
                          displayPrevious = TRUE,
                          fgColor = "#868686FF",
                          inputColor = "#428BCA"
                        ),
                       # addPopover("myKnob5", "Data", content = paste0("<p>Waiting time between ",
                        #                                                         "eruptions and the duration of the eruption for the Old Faithful geyser ",
                          #                                                       "in Yellowstone National Park, Wyoming, USA.</p><p>Azzalini, A. and ",
                             #                                                    "Bowman, A. W. (1990). A look at some data on the Old Faithful geyser. ",
                              #                                                   "Applied Statistics 39, 357-365.</p>"), trigger = 'click'),
                        column(5,
                               sliderInput("n", "Short tooltip", 5, 100, 20),
                               bsTooltip("n",title="This is a short tooltip, so it works."),
                               sliderInput("n2", "Long tooltip", 5, 100, 20),
                               bsTooltip("n2",title="This is a longer tooltip, which\\'ll still work, as long as each special character is escaped with a \\\\\\\\."))
                        

                        )
tab_ERE_A_5 <- tabPanel("Model Assessment",
                        h1("Highcharter Demo"),
                        fluidRow(
                          column(width = 4, class = "panel",
                                 selectInput("type", label = "Type", width = "100%",
                                             choices = c("line", "column", "bar", "spline")), 
                                 selectInput("stacked", label = "Stacked",  width = "100%",
                                             choices = c(FALSE, "normal", "percent")),
                                 selectInput("theme", label = "Theme",  width = "100%",
                                             choices = c(FALSE, "fivethirtyeight", "economist",
                                                         "darkunica", "gridlight", "sandsignika",
                                                         "null", "handdrwran", "chalk","monokai","ffx","tufte","db","flat","google")
                                 )
                          ),
                          column(width = 8,
                                 highchartOutput("hcontainer",height = "500px")
                          )
                        )
                        )
tab_ERE_A_6 <- tabPanel("Fraud indicators")
