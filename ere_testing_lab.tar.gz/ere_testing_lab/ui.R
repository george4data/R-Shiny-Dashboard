source('ui_ERE_A.R', local = TRUE)
#source('ui_ERE_B.R', local = TRUE)
#source('ui_ERE_C.R', local = TRUE)

ui <- tagList(
  ## Ther logo is loaded a javasctipt located at www folder.
  tags$head(tags$script(type = "text/javascript", src = "schwab_logo.js")),
  navbarPage(
    title = "ERE Dashboard",
    fluid = TRUE,
    theme = shinytheme("flatly"),
    ###### Here : insert shinydashboard dependencies ######
    header = tagList(useShinydashboard()),
    #######################################################
    navbarMenu(
      "WIRE Performance",
      tab_ERE_A_1,
      tab_ERE_A_2,
      tab_ERE_A_3,
      tab_ERE_A_4,
      tab_ERE_A_5,
      tab_ERE_A_6
    )
  )
)
