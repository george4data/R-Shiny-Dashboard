server <- function(input, output, session) {
  ####TO DO create two different observe events for drop down and datepicker
  # Home -------------------------------------------------------------------
  source('server_ERE_A.R', local = TRUE)
  #source('server_FSS_B.R', local = TRUE)
  #source('server_FSS_C.R', local = TRUE)
  
  
  
}  