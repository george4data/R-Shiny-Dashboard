$( document ).ready(function() {
  $( ".navbar .container-fluid" ).append( '<img src="images/logo.png" style="width:50px;height:48px;" align="right">' );
});